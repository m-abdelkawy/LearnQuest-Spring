package com.student;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootClientStudentApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootClientStudentApplication.class, args);
	}

}
